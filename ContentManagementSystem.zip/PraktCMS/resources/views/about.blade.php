    @extends('layouts.main')

    @section('container')
        <h1>ini about</h1>
        <p> {{ $kelas }}
            <br>
            {{ $nama }}
        </p>
    @endsection
    